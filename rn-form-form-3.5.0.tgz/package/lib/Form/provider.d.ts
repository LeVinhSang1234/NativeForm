import { MemoExoticComponent, PropsWithChildren } from 'react';
import { TField, TForm, FormItem, FormInstance, TItemValue, ValidateMessages } from './types';
import { LayoutRectangle, StyleProp, TextStyle } from 'react-native';
export type TFormContext<T> = {
    setField: (name: string, field: Omit<FormItem, 'name' | 'children'> & {
        triggerState: React.Dispatch<React.SetStateAction<TItemValue>>;
    }, value?: TItemValue) => void;
    unmountField: (name: string) => void;
    fields: TField;
    setLayout: (name: string, rect: LayoutRectangle) => void;
    setValue: (name: string, value: any, userAction?: boolean) => void;
    initialValues: Record<string, any>;
} & T;
export declare const useFormContext: () => TFormContext<Omit<TForm, "children" | "style" | "form">>;
export declare const getNestedValue: (source: Record<string, any>, path: string) => any;
export declare const FormProvider: ({ children, form, initialValues, scrollTo, onValuesChange, onFormDispose, ...formProps }: PropsWithChildren<TForm & {
    form: FormInstance<any>;
    scrollTo?: ((y: number) => void) | undefined;
}>) => import("react").JSX.Element;
type GlobalContext = {
    Text?: ((v: any) => React.JSX.Element) | MemoExoticComponent<(v: any) => React.JSX.Element>;
    errorStyle?: StyleProp<TextStyle>;
    labelStyle?: StyleProp<TextStyle>;
    requiredMark?: boolean | string;
    requiredMarkStyle?: StyleProp<TextStyle>;
    requiredMarkPosition?: 'before' | 'after';
    validateMessages?: ValidateMessages;
};
export declare const FormContextGlobal: import("react").Context<GlobalContext>;
export declare const useFormContextGlobal: () => GlobalContext;
export declare const FormGlobalProvider: ({ children, ...p }: PropsWithChildren<GlobalContext>) => import("react").JSX.Element;
export {};
//# sourceMappingURL=provider.d.ts.map