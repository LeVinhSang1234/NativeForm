import React from 'react';
import { NativeSyntheticEvent, StyleProp, TextInputChangeEventData, TextInputProps, TextStyle, ViewStyle } from 'react-native';
export declare type ITextInputProps = {
    error?: string | boolean;
    onChangeValue?: (v: string) => any;
    style?: StyleProp<ViewStyle>;
    styleInput?: StyleProp<TextStyle>;
    activeBorderColor?: string;
    rangeBorderColor?: string;
    borderColor?: string;
    onChange?: (v: NativeSyntheticEvent<TextInputChangeEventData>) => any;
};
declare const Input: ({ error, onChangeValue, style, styleInput, activeBorderColor, rangeBorderColor, borderColor: borderColorProps, onChange, multiline, onChangeText, value, onFocus, onBlur, ...props }: ITextInputProps & TextInputProps) => React.JSX.Element;
export default Input;
//# sourceMappingURL=index.d.ts.map