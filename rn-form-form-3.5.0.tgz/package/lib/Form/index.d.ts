import React, { PropsWithChildren } from 'react';
import { FormInstance, TForm } from './types';
import { ScrollViewProps, ScrollView as ScrollViewLibrary } from 'react-native';
export declare const useForm: <T>(initialValues?: Partial<T> | undefined) => FormInstance<T>;
declare const Form: {
    <T>({ style, ...props }: React.PropsWithChildren<TForm<T>>): React.JSX.Element;
    Item: <T_1 = any, K extends keyof T_1 = keyof T_1>({ children, name, getValueProps: getValuePropsProp, normalize, required, label, rules, validateTrigger, preserve: itemPreserve, initialValue, style, errorStyle: itemErrorStyle, labelStyle: itemLabelStyle, messageError, }: import("./types").FormItem<T_1, K>) => React.JSX.Element;
    ScrollView: React.ForwardRefExoticComponent<Omit<TForm<any>, "style"> & ScrollViewProps & {
        children?: React.ReactNode;
    } & React.RefAttributes<ScrollViewLibrary>>;
};
export default Form;
//# sourceMappingURL=index.d.ts.map