import {
  createContext,
  MemoExoticComponent,
  PropsWithChildren,
  useCallback,
  useContext,
  useEffect,
  useRef,
} from 'react';
import {
  defaultValidateMessages,
  TField,
  TForm,
  TriggerAction,
  FormItem,
  FormInstance,
  FilterGetValues,
  TItemValue,
  ValidateMessages,
  KeyboardManagerConfig,
  defaultKeyboardManager,
} from './types';
import {validate} from './validateItem';
import {LayoutRectangle, StyleProp, TextStyle} from 'react-native';

export type TFormContext<T> = {
  setField: (
    name: string,
    field: Omit<FormItem, 'name' | 'children'> & {
      triggerState: React.Dispatch<React.SetStateAction<TItemValue>>;
    },
    value?: TItemValue,
  ) => void;
  unmountField: (name: string) => void;
  fields: TField;
  setLayout: (name: string, rect: LayoutRectangle) => void;
  setValue: (name: string, value: any, userAction?: boolean) => void;
  initialValues: Record<string, any>;
} & T;

const FormContext = createContext<
  TFormContext<Omit<TForm, 'form' | 'children' | 'style'>>
>({
  setField: () => null,
  unmountField: () => null,
  fields: {},
  colon: true,
  labelAlign: 'left',
  requiredMark: true,
  validateMessages: defaultValidateMessages,
  validateTrigger: TriggerAction.onChange,
  initialValues: {},
  setValue: () => null,
  setLayout: () => null,
});

export const useFormContext = () => useContext(FormContext);

const toNestedObject = (flat: Record<string, any>) => {
  const result: Record<string, any> = {};
  Object.keys(flat).forEach(flatKey => {
    const parts = flatKey
      .split('.')
      .map(k => (k.match(/^\d+$/) ? Number(k) : k));
    let cursor: any = result;
    parts.forEach((key, idx) => {
      const isLeaf = idx === parts.length - 1;
      if (isLeaf) {
        cursor[key] = flat[flatKey];
        return;
      }
      if (cursor[key] === undefined) {
        cursor[key] = typeof parts[idx + 1] === 'number' ? [] : {};
      }
      cursor = cursor[key];
    });
  });
  return result;
};

const isPlainObject = (v: any): boolean => {
  if (v === null || typeof v !== 'object' || Array.isArray(v)) return false;
  const proto = Object.getPrototypeOf(v);
  return proto === Object.prototype || proto === null;
};

const flattenValues = (
  input: Record<string, any>,
  fields: Record<string, any>,
  prefix = '',
): Record<string, any> => {
  const result: Record<string, any> = {};
  Object.keys(input).forEach(key => {
    const path = prefix ? `${prefix}.${key}` : key;
    const value = input[key];
    if (isPlainObject(value) && !fields[path]) {
      Object.assign(result, flattenValues(value, fields, path));
    } else {
      result[path] = value;
    }
  });
  return result;
};

const deepMergeInto = (
  target: Record<string, any>,
  source: Record<string, any>,
) => {
  Object.keys(source).forEach(key => {
    if (isPlainObject(source[key]) && isPlainObject(target[key])) {
      deepMergeInto(target[key], source[key]);
    } else {
      target[key] = source[key];
    }
  });
  return target;
};

export const getNestedValue = (
  source: Record<string, any>,
  path: string,
): any =>
  path.split('.').reduce((acc: any, key) => {
    if (acc == null) return undefined;
    const idx = Number(key);
    if (!Number.isNaN(idx) && Array.isArray(acc)) {
      return acc[idx];
    }
    return acc[key];
  }, source);

const getChildKeys = (store: Record<string, any>, name: string): string[] => {
  const prefix = name + '.';
  return Object.keys(store).filter(key => key.startsWith(prefix));
};

export const FormProvider = ({
  children,
  form,
  initialValues = {},
  scrollTo,
  onValuesChange,
  onFormDispose,
  ...formProps
}: PropsWithChildren<
  TForm & {form: FormInstance<any>; scrollTo?: (y: number) => void}
>) => {
  const fields = useRef<TField>({});
  const touched = useRef<Record<string, boolean>>({});
  const layout = useRef<Record<string, LayoutRectangle>>({});
  const values = useRef<Record<string, TItemValue>>({});
  const mergedInitialValues = useRef<Record<string, any>>({...initialValues});
  const prevInitialValues = useRef(initialValues);
  if (prevInitialValues.current !== initialValues) {
    prevInitialValues.current = initialValues;
    mergedInitialValues.current = {
      ...mergedInitialValues.current,
      ...initialValues,
    };
  }
  const changeTimeout = useRef<ReturnType<typeof setTimeout> | null>(null);
  const onValuesChangeRef = useRef(onValuesChange);
  onValuesChangeRef.current = onValuesChange;

  const fireValuesChange = useCallback(() => {
    if (changeTimeout.current) clearTimeout(changeTimeout.current);
    changeTimeout.current = setTimeout(() => {
      const plainValues: Record<string, any> = {};
      for (const key in values.current) {
        plainValues[key] = values.current[key]?.value;
      }
      onValuesChangeRef.current?.(plainValues);
    }, 150);
  }, []);

  const setValue = useCallback(
    (name: string, value: TItemValue, userAction?: boolean) => {
      values.current[name] = value;
      if (userAction) {
        if (!touched.current[name]) touched.current[name] = true;
      }
      fireValuesChange();
    },
    [fireValuesChange],
  );

  const setField = useCallback(
    (
      name: string,
      field: Omit<FormItem, 'name' | 'children'>,
      value?: TItemValue,
    ) => {
      if (fields.current[name]?.preserve && !field.preserve) {
        delete values.current?.[name];
        delete touched.current?.[name];
      }
      fields.current[name] = field;
      if (value !== undefined) values.current[name] = value;
    },
    [],
  );

  const setLayout = useCallback((name: string, rect: LayoutRectangle) => {
    layout.current[name] = rect;
  }, []);

  const unmountField = useCallback((name: string) => {
    delete layout.current[name];
    if (fields.current?.[name]?.preserve) return;
    delete values.current?.[name];
    delete fields.current?.[name];
    delete touched.current?.[name];
  }, []);

  const getFieldError = useCallback((name: any) => {
    if (values.current[name]?.error) {
      return values.current[name]?.error;
    }
    const errors: Record<string, string> = {};
    getChildKeys(values.current, name).forEach(key => {
      const itemError = values.current[key]?.error;
      if (itemError) {
        errors[key] = itemError as string;
      }
    });
    return Object.keys(errors).length === 0 ? undefined : errors;
  }, []);

  const getFieldsError = useCallback(
    async (
      names: any[] = Object.keys(fields.current),
    ): Promise<{[key: string]: string | undefined}> => {
      const errors: {[key: string]: string | undefined} = {};
      names.forEach(name => {
        const currentError = values.current[name]?.error;
        if (currentError) errors[name] = currentError;
        getChildKeys(values.current, name).forEach(key => {
          const itemError = values.current[key]?.error;
          if (itemError) {
            errors[key] = itemError;
          }
        });
      });
      return errors;
    },
    [],
  );

  const getFieldsValue = useCallback(
    async (names?: any[], filter?: FilterGetValues) => {
      let keys: string[];
      if (!names) {
        keys = Object.keys(fields.current);
      } else {
        keys = [];
        names.forEach(name => {
          if (values.current[name] !== undefined) {
            keys.push(name);
          }
          getChildKeys(values.current, name).forEach(key => {
            if (!keys.includes(key)) {
              keys.push(key);
            }
          });
        });
      }
      if (typeof filter === 'function') {
        keys = keys.filter(e => filter(touched.current[e]));
      }
      const flat: Record<string, any> = keys.reduce((a, b) => {
        a[b] = values.current[b]?.value;
        return a;
      }, {} as Record<string, any>);
      return toNestedObject(flat);
    },
    [],
  );

  const getFieldValue = useCallback((name: any) => {
    if (values.current[name]?.value !== undefined) {
      return values.current[name]?.value;
    }
    const childKeys = getChildKeys(values.current, name);
    if (childKeys.length === 0) return undefined;
    const flat: Record<string, any> = {};
    childKeys.forEach(key => {
      flat[key] = values.current[key]?.value;
    });
    return toNestedObject(flat)[name];
  }, []);

  const setFieldError = useCallback((name: any, error?: string | false) => {
    values.current[name] = {...values.current[name], error: error || ''};
    fields.current[name]?.triggerState?.(values.current[name]);
  }, []);

  const isFieldsTouched = useCallback(
    (names: any[] = Object.keys(fields.current)): boolean => {
      const allKeys: string[] = [];
      names.forEach(name => {
        if (touched.current[name] !== undefined) allKeys.push(name);
        getChildKeys(fields.current, name).forEach(key => {
          if (!allKeys.includes(key)) {
            allKeys.push(key);
          }
        });
      });
      if (allKeys.length === 0) return false;
      return allKeys.every(n => touched.current[n]);
    },
    [],
  );

  const isFieldTouched = useCallback((name: any): boolean => {
    if (touched.current[name]) return true;
    return getChildKeys(fields.current, name).some(key => touched.current[key]);
  }, []);

  const isValuesChanged = useCallback(
    (names: any[] = Object.keys(fields.current)) => {
      return names.some(name => touched.current[name]);
    },
    [],
  );

  const clearTouched = useCallback((names?: any[]) => {
    const keys = names ?? Object.keys(touched.current);
    keys.forEach(name => {
      delete touched.current[name];
    });
  }, []);

  const resetFields = useCallback(
    async (names: any[] = Object.keys(fields.current)) => {
      await Promise.all(
        names.map(async name => {
          const initial = getNestedValue(mergedInitialValues.current, name);
          const v = fields.current[name]?.normalize?.(initial) ?? initial;
          values.current[name] = {value: v};
          if (touched.current[name]) delete touched.current[name];
          return fields.current[name]?.triggerState?.({
            value: v,
          });
        }),
      );
    },
    [],
  );

  const setFieldValue = useCallback((name: any, value: any) => {
    const v = fields.current[name]?.normalize?.(value) ?? value;
    values.current[name] = {value: v};
    if (!touched.current[name]) touched.current[name] = true;
    fields.current[name]?.triggerState?.({value: v});
  }, []);

  const setInitFieldsValue = useCallback(
    async (_values: {[key: string]: any}) => {
      deepMergeInto(mergedInitialValues.current, _values);
      const flat = flattenValues(_values, fields.current);
      await Promise.all(
        Object.keys(flat).map(async name => {
          const v = fields.current[name]?.normalize?.(flat[name]) ?? flat[name];
          values.current[name] = {value: v};
          return fields.current[name]?.triggerState?.({
            value: v,
          });
        }),
      );
    },
    [],
  );

  const setFieldsValue = useCallback(
    async (_values: {[key: string]: any}) => {
      const flat = flattenValues(_values, fields.current);
      await Promise.all(
        Object.keys(flat).map(async name => {
          const v = fields.current[name]?.normalize?.(flat[name]) ?? flat[name];
          values.current[name] = {value: v};
          if (!touched.current[name]) touched.current[name] = true;
          return fields.current[name]?.triggerState?.({
            value: v,
          });
        }),
      );
      fireValuesChange();
    },
    [fireValuesChange],
  );

  const validateFields = useCallback(
    async (names: any[] = Object.keys(fields.current)) => {
      const _values: {[key: string]: any} = {};
      let _errors: {[key: string]: string | undefined} | undefined;
      const errs = await Promise.all(
        names.map(async name => {
          const field = fields.current[name];
          const raw = values.current[name]?.value;
          const v = field?.normalize?.(raw) ?? raw;
          const error = await validate(
            v,
            {...field, name},
            TriggerAction.all,
            formProps.validateMessages,
          );
          _values[name] = v;
          if (error?.[0]) {
            if (!_errors) _errors = {};
            _errors[name] = error?.[0];
          }
          values.current[name] = {value: v, error: _errors?.[name]};
          fields.current[name]?.triggerState?.(values.current[name]);
          if (_errors?.[name]) return name;
        }),
      );
      const firstError = errs.find(Boolean);
      if (scrollTo && firstError) {
        const y = layout.current[firstError]?.y;
        scrollTo(y);
      }
      return {values: toNestedObject(_values), errors: _errors} as any;
    },
    [formProps.validateMessages, scrollTo],
  );

  useEffect(() => {
    form.getFieldError = getFieldError;
    form.getFieldsError = getFieldsError;
    form.getFieldsValue = getFieldsValue;
    form.getFieldValue = getFieldValue;
    form.isFieldsTouched = isFieldsTouched;
    form.isFieldTouched = isFieldTouched;
    form.isValuesChanged = isValuesChanged;
    form.resetFields = resetFields;
    form.setFieldValue = setFieldValue;
    form.setFieldsValue = setFieldsValue;
    form.setInitFieldsValue = setInitFieldsValue;
    form.validateFields = validateFields;
    form.setFieldError = setFieldError;
    form.clearTouched = clearTouched;
    form._ready = true;
  }, [
    form,
    clearTouched,
    getFieldError,
    getFieldValue,
    getFieldsError,
    getFieldsValue,
    isFieldTouched,
    isFieldsTouched,
    isValuesChanged,
    resetFields,
    setFieldError,
    setFieldValue,
    setFieldsValue,
    setInitFieldsValue,
    validateFields,
  ]);

  useEffect(() => {
    const v = values;
    const t = touched;
    return () => {
      if (!onFormDispose) return;
      const plainValues: Record<string, any> = {};
      let errors: Record<string, string | undefined> | undefined;
      for (const key in v.current) {
        plainValues[key] = v.current[key]?.value;
        if (v.current[key]?.error) {
          if (!errors) errors = {};
          errors[key] = v.current[key].error;
        }
      }
      const isChanged = Object.keys(t.current).some(name => t.current[name]);
      onFormDispose?.({
        values: toNestedObject(plainValues),
        errors,
        isChanged,
      });
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [initialValues]);

  return (
    <FormContext.Provider
      value={{
        ...formProps,
        fields: fields.current,
        setField,
        unmountField,
        initialValues,
        setValue,
        setLayout,
      }}>
      {children}
    </FormContext.Provider>
  );
};

type GlobalContext = {
  Text?:
    | ((v: any) => React.JSX.Element)
    | MemoExoticComponent<(v: any) => React.JSX.Element>;
  errorStyle?: StyleProp<TextStyle>;
  labelStyle?: StyleProp<TextStyle>;
  requiredMark?: boolean | string; //Required mark style. Can use required mark or optional mark. You can not config to single Form.Item since this is a Form level config
  requiredMarkStyle?: StyleProp<TextStyle>;
  requiredMarkPosition?: 'before' | 'after';
  validateMessages?: ValidateMessages; //Validation prompt template
  keyboardManager?: KeyboardManagerConfig; //Tune the native keyboard manager. Turn it on per Form with the keyboardManager prop
};

export const FormContextGlobal = createContext<GlobalContext>({
  keyboardManager: defaultKeyboardManager,
});

export const useFormContextGlobal = () => useContext(FormContextGlobal);

export const FormGlobalProvider = ({
  children,
  keyboardManager,
  ...p
}: PropsWithChildren<GlobalContext>) => {
  return (
    <FormContextGlobal.Provider
      value={{
        ...p,
        keyboardManager: {...defaultKeyboardManager, ...keyboardManager},
      }}>
      {children}
    </FormContextGlobal.Provider>
  );
};
