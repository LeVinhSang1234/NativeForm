import { ReactNode } from 'react';
import { ColorValue, StyleProp, TextStyle, ViewStyle } from 'react-native';
export declare type ValidateMessages = {
    required?: string;
    whitespace?: string;
    len?: string;
    min?: string;
    max?: string;
    pattern?: string;
    enum?: string;
};
export declare enum TriggerAction {
    onChange = "onChange",
    onBlur = "onBlur",
    all = "all"
}
export declare type Rule = {
    required?: boolean;
    enum?: any[];
    len?: number;
    max?: number;
    min?: number;
    message?: string;
    pattern?: RegExp;
    transform?: (value: any) => any;
    validateTrigger?: TriggerAction | 'onChange' | 'onBlur';
    validator?: (rule: Rule & {
        name: string;
    }, value: any, callback: (errorMessage?: string) => void) => Promise<void | Error>;
    whitespace?: boolean;
};
export declare type FormItem<T = any, K extends keyof T = keyof T> = {
    name: K;
    label?: string;
    initialValue?: T[K];
    rules?: Rule[];
    required?: boolean;
    validateTrigger?: TriggerAction.onBlur | TriggerAction.onChange;
    messageError?: string;
    preserve?: boolean;
    style?: StyleProp<ViewStyle>;
    errorStyle?: StyleProp<TextStyle>;
    labelStyle?: StyleProp<TextStyle>;
    getValueProps?: (v: T[K]) => any;
    normalize?: (v: any) => T[K];
    children: ((handle: {
        onChangeValue: (value: T[K]) => void;
        onBlur: () => void;
        value?: T[K];
        error?: string;
    }) => ReactNode) | React.ReactNode;
};
export declare const defaultValidateMessages: {
    required: string;
    whitespace: string;
    len: string;
    min: string;
    max: string;
    pattern: string;
    enum: string;
};
export declare type KeyboardManagerConfig = {
    distance?: number;
    toolbar?: boolean;
    toolbarDoneText?: string;
    toolbarPreviousNext?: boolean;
    toolbarPlaceholder?: boolean;
    toolbarTintColor?: ColorValue;
    toolbarBarTintColor?: ColorValue;
    keyboardAppearance?: 'default' | 'light' | 'dark';
};
export declare const defaultKeyboardManager: KeyboardManagerConfig;
export declare type FilterGetValues = (touched: boolean) => true;
export declare type ValueValidateField<T = any> = {
    values: T;
    errors?: {
        [key: string]: string;
    };
};
export type NamePath<T> = Extract<keyof T, string> | (string & {});
export declare type FormInstance<T = Record<string, any>> = {
    getFieldError: (name: NamePath<T>) => string | undefined | Record<string, string>;
    getFieldsError: (names?: NamePath<T>[]) => Promise<{
        [key: string]: string | undefined;
    }>;
    getFieldsValue: (names?: NamePath<T>[], filter?: FilterGetValues) => Promise<any>;
    getFieldValue: (name: NamePath<T>) => any;
    isFieldsTouched: (names?: string[]) => boolean;
    isFieldTouched: (name: NamePath<T>) => boolean;
    isValuesChanged: (names?: NamePath<T>[]) => boolean;
    resetFields: (fields?: NamePath<T>[]) => Promise<void>;
    setFieldValue: (name: keyof T, value: any) => void;
    setFieldsValue: (values: {
        [key in NamePath<T>]?: any;
    }) => Promise<void>;
    setInitFieldsValue: (values: {
        [key in NamePath<T>]?: any;
    }) => Promise<void>;
    validateFields: (names?: NamePath<T>[]) => Promise<ValueValidateField<T>>;
    setFieldError: (name: NamePath<T>, error?: string | false) => void;
    clearTouched: (names?: NamePath<T>[]) => void;
    id: number;
    /** @internal */
    _ready: boolean;
    isReady: (timeout?: number) => Promise<void>;
    initialValues?: Partial<T>;
};
export type TForm<T = any> = {
    form: FormInstance<T>;
    colon?: boolean;
    initialValues?: Partial<T>;
    labelAlign?: 'left' | 'right';
    name?: string;
    preserve?: boolean;
    requiredMark?: boolean | string;
    requiredMarkStyle?: StyleProp<TextStyle>;
    requiredMarkPosition?: 'before' | 'after';
    validateMessages?: ValidateMessages;
    validateTrigger?: TriggerAction | 'onChange' | 'onBlur';
    onValuesChange?: (values: T) => void;
    keyboardManager?: boolean;
    onFormDispose?: (info: {
        values: T;
        errors: {
            [key: string]: string | undefined;
        } | undefined;
        isChanged: boolean;
    }) => void;
    errorStyle?: StyleProp<TextStyle>;
    labelStyle?: StyleProp<TextStyle>;
    style?: StyleProp<ViewStyle>;
};
export type TItemValue = {
    value: any;
    error?: string;
};
export type TField = {
    [key: string]: Omit<FormItem, 'name' | 'children'> & {
        triggerState?: React.Dispatch<React.SetStateAction<TItemValue>>;
    };
};
//# sourceMappingURL=types.d.ts.map